<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$CONFIG = [
	// How long before the renewal date should the status be changed
	// ex. -2 month, -1 day https://secure.php.net/manual/en/datetime.formats.php
	'RENEWAL_TIME' => '-2 month',
];
