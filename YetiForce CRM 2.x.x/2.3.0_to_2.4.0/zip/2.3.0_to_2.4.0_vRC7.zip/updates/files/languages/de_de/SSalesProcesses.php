<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'SSalesProcesses' => 'Verkaufschancen',
	'SINGLE_SSalesProcesses' => 'Verkaufschance',
	
	//BLOCKS
	'LBL_SSALESPROCESSES_INFORMATION' => 'Informationen',
	'LBL_CUSTOM_INFORMATION' => 'System Information',
	'LBL_DESCRIPTION_INFORMATION' => 'Beschreibung Details',

	//FIELDS
	'LBL_SUBJECT' => 'Bezeichnung',
	'LBL_NUMBER' => 'Nummer',
	'LBL_CLOSED_TIME' => 'Beendigungszeit',

];
