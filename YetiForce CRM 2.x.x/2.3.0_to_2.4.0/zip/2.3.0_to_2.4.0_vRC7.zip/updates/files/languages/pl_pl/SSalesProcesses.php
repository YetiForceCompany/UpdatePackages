<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'SSalesProcesses' => 'Szanse sprzedaży',
	'SINGLE_SSalesProcesses' => 'Szansa sprzedaży',
	
	//BLOCKS
	'LBL_SSALESPROCESSES_INFORMATION' => 'Informacje podstawowe',
	'LBL_CUSTOM_INFORMATION' => 'Informacje systemowe',
	'LBL_DESCRIPTION_INFORMATION' => 'Informacje Opisowe',
	
	//FIELDS
	'LBL_SUBJECT' => 'Temat',
	'LBL_NUMBER' => 'Numer',
	'LBL_CLOSED_TIME' => 'Czas zamknięcia',
];
