<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'Competition' => 'Competition',
	'SINGLE_Competition' => 'Competitor',
	
	//BLOCKS
	'LBL_COMPETITION_INFORMATION' => 'Basic information',
	'LBL_CUSTOM_INFORMATION' => 'System Information',
	'LBL_DESCRIPTION_INFORMATION' => 'Description Details',
	
	//FIELDS
	'LBL_SUBJECT' => 'Subject',
	'LBL_NUMBER' => 'Number',
	'LBL_CLOSED_TIME' => 'Closed Time',
	'LBL_VAT_ID' => 'Tax ID',

];
