<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$CONFIG = [
	'DEFAULT_VIEW_RECORD' => 'LBL_RECORD_PREVIEW',
];
