<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'Competition' => 'Competition',
	'SINGLE_Competition' => 'Competitor',

	//BLOCKS
	'LBL_COMPETITION_INFORMATION' => 'Informações básicas',
	'LBL_CUSTOM_INFORMATION' => 'System Information',
	'LBL_DESCRIPTION_INFORMATION' => 'Description Details',

	//FIELDS
	'LBL_SUBJECT' => 'Assunto',
	'LBL_NUMBER' => 'Número',
	'LBL_CLOSED_TIME' => 'Hora Fechamento',
	'LBL_VAT_ID' => 'Imposto',
];
