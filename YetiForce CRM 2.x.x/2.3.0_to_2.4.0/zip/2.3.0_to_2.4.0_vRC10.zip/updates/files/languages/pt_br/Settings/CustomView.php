<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */

$languageStrings = [
	'CustomView'	=> 'Filters - Configuration',
	'LBL_MODULE_DESC'	=> 'Esta ferramenta permite configurar visualizações customizadas para os módulos. Estes módulos devem conter registros e utilizar filtros padrões do YetiForce CRM.',
	'Module'	=> 'Módulo',
	'ViewName'	=> 'Nome da Visualização',
	'SetDefault'	=> 'Padrão',
	'Privileges'	=> 'Privilégios',
	'Delete'	=> 'Apagar',
	'Delete CustomView'	=> 'A visualização customizada foi apagada',
	'Saving CustomView'	=> 'A visualização foi salva',
	'Actions'	=> 'Ações',
	'Edit'	=> 'Editar',
];
$jsLanguageStrings = [
	'Saving changes'	=> 'Savando as alterações...',
	'Update labels'	=> 'Atualização',
];
