/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */

jQuery.Class("Calendar_ActivityStateModal_Js", {}, {
	registerActivityState: function () {
		var thisInstance = this;
		jQuery('#activityStateModal button:not(.close)').on('click', function (e) {
			var currentTarget = jQuery(e.currentTarget);
			currentTarget.closest('.modal').addClass('hide');

			if (currentTarget.hasClass('showQuickCreate')) {
				var progressIndicatorElement = jQuery.progressIndicator({
					'position': 'html',
					'blockInfo': {
						'enabled': true
					}
				});
				var moduleName = 'Calendar';
				var url = 'index.php?module=Calendar&view=QuickCreateAjax&sourceModule=Calendar&sourceRecord=' + currentTarget.data('id');
				var headerInstance = Vtiger_Header_Js.getInstance();
				headerInstance.getQuickCreateForm(url, moduleName).then(function (data) {
					progressIndicatorElement.progressIndicator({'mode': 'hide'})
					headerInstance.handleQuickCreateData(data, {callbackFunction: function (data) {
							if (data && data.success) {
								thisInstance.updateActivityState(currentTarget);
							}
						}});
				});
			} else {
				thisInstance.updateActivityState(currentTarget);
			}

		});
	},
	updateActivityState: function (currentTarget) {
		var thisInstance = this;
		var params = {
			'module': 'Calendar',
			'action': "ActivityStateAjax",
			'id': currentTarget.data('id'),
			'state': currentTarget.data('state')
		}
		app.hideModalWindow();
		var progressIndicatorElement = jQuery.progressIndicator({
			'position': 'html',
			'blockInfo': {
				'enabled': true
			}
		});
		AppConnector.request(params).then(
				function (data) {
					if (data.success) {
						var viewName = app.getViewName();
						if (viewName === 'Detail') {
							var widget = jQuery('.activityWidgetContainer .widgetContentBlock');
								var thisInstance = Vtiger_Detail_Js.getInstance();
							if(widget.length){
								thisInstance.loadWidget(widget);
							}else{
								var recentActivitiesTab = thisInstance.getTabByLabel(thisInstance.detailViewRecentActivitiesTabLabel);
								if(recentActivitiesTab){
									recentActivitiesTab.trigger('click');
								}
								if (app.getModuleName() == 'Calendar'){
									recentActivitiesTab = ((!thisInstance.getSelectedTab().length || thisInstance.getSelectedTab().data('linkKey') == thisInstance.detailViewDetailsTabLabel) ? thisInstance.getTabContainer().find('[data-link-key="'+thisInstance.detailViewDetailsTabLabel+'"]') : jQuery('<div></div>'));
									jQuery('.showModal.closeCalendarRekord').addClass('hide');
									recentActivitiesTab.trigger('click');
								}
							}
						}
						if (viewName == 'List') {
							var listinstance = new Vtiger_List_Js();
							listinstance.getListViewRecords();
						}
						if (viewName == 'DashBoard') {
							var instance = new Vtiger_DashBoard_Js();
							instance.getContainer().find('a[name="drefresh"]').trigger('click');
						}
						if (app.getModuleName() == 'Calendar' && viewName == 'Calendar') {
							var instance = Calendar_CalendarView_Js.getInstanceByView();
							instance.loadCalendarData();
						}
						//updates the Calendar Reminder popup's status
						Vtiger_Index_Js.requestReminder();
						progressIndicatorElement.progressIndicator({'mode': 'hide'});
					} else {
						return false;
					}
				}
		);
	},
	registerEvents: function () {
		this.registerActivityState();
	}

});

jQuery(document).ready(function (e) {
	var instance = new Calendar_ActivityStateModal_Js();
	instance.registerEvents();
})
