<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'KnowledgeBase' => 'Baza wiedzy',
	'SINGLE_KnowledgeBase' => 'KnowledgeBase',
	'KnowledgeBase ID' => 'KnowledgeBase ID',
	'LBL_CUSTOM_INFORMATION' => 'Informacje opisowe',
	'FL_SUBJECT' => 'Tytuł',
	'LBL_KNOWLEDGEBASE_INFORMATION' => 'Informacje podstawowe',
	'FL_CONTENT' => 'Treść',
	'FL_CATEGORY' => 'Kategoria',
	'FL_VIEWS' => 'Widok',
	'PLL_PAGE' => 'Strona',
	'PLL_PRESENTATION' => 'Prezentacja',
	'LBL_VIEW_TREE' => 'Drzewo rekordów',
	'LBL_PREVIOUS' => 'Poprzedni',
	'LBL_NEXT' => 'Następny',
	'LBL_LIST_RECORDS' => 'Lista dokumentów',
];
