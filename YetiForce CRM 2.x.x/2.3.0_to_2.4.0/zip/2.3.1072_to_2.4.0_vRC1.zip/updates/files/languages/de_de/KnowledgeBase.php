<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'KnowledgeBase' => 'KnowledgeBase',
	'SINGLE_KnowledgeBase' => 'KnowledgeBase',
	'KnowledgeBase ID' => 'KnowledgeBase ID',
	'LBL_CUSTOM_INFORMATION' => 'Custom Information',
	'subject' => 'subject',
];
