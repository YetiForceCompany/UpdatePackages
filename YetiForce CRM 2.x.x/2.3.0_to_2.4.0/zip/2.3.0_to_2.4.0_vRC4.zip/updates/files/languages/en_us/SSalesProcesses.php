<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'SSalesProcesses' => 'Sales processes',
	'SINGLE_SSalesProcesses' => 'Sales process',
	
	//BLOCKS
	'LBL_SSALESPROCESSES_INFORMATION' => 'Basic information',
	'LBL_CUSTOM_INFORMATION' => 'System Information',
	'LBL_DESCRIPTION_INFORMATION' => 'Description Details',
	
	//FIELDS
	'LBL_SUBJECT' => 'Subject',
	'LBL_NUMBER' => 'Number',
	'LBL_CLOSED_TIME' => 'Closed Time',

];
