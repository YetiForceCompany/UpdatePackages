<?php
/*+***********************************************************************************************************************************
 * The contents of this file are subject to the YetiForce Public License Version 1.1 (the "License"); you may not use this file except
 * in compliance with the License.
 * Software distributed under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.
 * See the License for the specific language governing rights and limitations under the License.
 * The Original Code is YetiForce.
 * The Initial Developer of the Original Code is YetiForce. Portions created by YetiForce are Copyright (C) www.yetiforce.com. 
 * All Rights Reserved.
 *************************************************************************************************************************************/
$languageStrings = [
	'HideBlocks' => 'Редактор Блоков',
	'LBL_HIDEBLOCKS' => 'Fields – Hide Blocks',
	'LBL_HIDEBLOCKS_DESCRIPTION' => 'Редактор блоков, позволяет настраивать видимость Блоков в записях',
	'LBL_BLOCK_LABEL' => 'Блок',
	'LBL_MODULE' => 'Модуль',
	'LBL_ENABLED' => 'Активирован',
	'LBL_EDIT_BLOCK' => 'Изменить',
	'LBL_NEW_BLOCK' => 'Создать',
	'LBL_BLOCK' => 'Блок',
	'LBL_ENABLED' => 'Активирован',
	'LBL_NEXT' => 'Далее',
	'LBL_VIEW' => 'Отображать в',
	'LBL_MANDATORY_FIELDS_EXIST' => 'Этот Блок не может быть скрыт, потому что он содержит обязательные поля.',
];
