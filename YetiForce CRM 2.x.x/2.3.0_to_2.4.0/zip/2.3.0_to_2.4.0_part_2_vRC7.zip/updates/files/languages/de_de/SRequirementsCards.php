<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'SRequirementsCards' => 'Sales requirements',
	'SINGLE_SRequirementsCards' => 'Sales requirement', 
	
	//BLOCKS
	'LBL_SREQUIREMENTSCARDS_INFORMATION' => 'Informationen',
	'LBL_CUSTOM_INFORMATION' => 'System Information',
	'LBL_DESCRIPTION_INFORMATION' => 'Beschreibung Details',
	'LBL_STATISTICS' => 'Statistics',

	//FIELDS
	'LBL_SUBJECT' => 'Bezeichnung',
	'LBL_NUMBER' => 'Nummer',
	'LBL_STATUS' => 'Status',
	'LBL_CLOSED_TIME' => 'Beendigungszeit',
	'LBL_RESPONSE_TIME' => 'Respone time',
	'SINGLE_SSalesProcesses' => 'Verkaufschance',

	//PICKLIST VALUES
	'PLL_DRAFT' => 'Draft',
	'PLL_IN_REALIZATION' => 'In realization',
	'PLL_FOR_VERIFICATION' => 'For verification',
	'PLL_CANCELLED' => 'Cancelled',
	'PLL_COMPLETED' => 'Completed',

	'LBL_CHANGE_STATUS' => 'Change Status',

];
