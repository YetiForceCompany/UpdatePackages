<?php
/* {[The file is published on the basis of YetiForce Public License
 * that can be found in the following directory: licenses/License.html]} */

$languageStrings = [
	'Export' => 'Экспорт',
	'LBL_INFO_USER_EXPORT_RECORDS' => 'Экспорт разрешен только активным пользователям',
];
