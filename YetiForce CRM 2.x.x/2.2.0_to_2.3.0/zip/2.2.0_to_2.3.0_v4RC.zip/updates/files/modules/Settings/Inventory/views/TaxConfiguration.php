<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */

class Settings_Inventory_TaxConfiguration_View extends Settings_Inventory_DiscountConfiguration_View
{

	public function getView()
	{
		return 'TaxConfiguration';
	}
}
