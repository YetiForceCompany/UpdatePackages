<?php
/* {[The file is published on the basis of YetiForce Public License
 * that can be found in the following directory: licenses/License.html]} */

$languageStrings = [
	'Export' => 'Export',
	'LBL_INFO_USER_EXPORT_RECORDS' => "It's only possible to export active users",
];
