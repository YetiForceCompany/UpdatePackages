<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */

// key will be protected backup files
$backupPassword = 'yeti';
