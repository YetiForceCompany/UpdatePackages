<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'Competition' => 'Konkurenci',
	'SINGLE_Competition' => 'Konkurent',
	
	//BLOCKS
	'LBL_COMPETITION_INFORMATION' => 'Informacje podstawowe',
	'LBL_CUSTOM_INFORMATION' => 'Informacje systemowe',
	'LBL_DESCRIPTION_INFORMATION' => 'Informacje opisowe',
	
	//FIELDS
	'LBL_SUBJECT' => 'Temat',
	'LBL_NUMBER' => 'Numer',
	'LBL_CLOSED_TIME' => 'Czas zamknięcia',
	'LBL_VAT_ID' => 'NIP',
];
