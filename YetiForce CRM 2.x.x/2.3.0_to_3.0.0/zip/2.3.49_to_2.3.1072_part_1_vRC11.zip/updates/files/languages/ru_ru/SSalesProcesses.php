<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'SSalesProcesses' => 'Сделки',
	'SINGLE_SSalesProcesses' => 'Сделка',

	//BLOCKS
	'LBL_SSALESPROCESSES_INFORMATION' => 'Основная информация',
	'LBL_CUSTOM_INFORMATION' => 'Дополнительная информация',
	'LBL_DESCRIPTION_INFORMATION' => 'Описание',

	
	//FIELDS
	'LBL_CLOSED_TIME' => 'Время закрытия',
	'LBL_SUBJECT' => 'Тема',
	'LBL_NUMBER' => 'Номер',
];
