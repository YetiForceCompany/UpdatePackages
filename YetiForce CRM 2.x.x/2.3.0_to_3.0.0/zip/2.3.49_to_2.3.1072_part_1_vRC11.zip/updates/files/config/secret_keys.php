<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$SECURITY_KEYS_CONFIG = [
	// key will be protected backup files
	'backupPassword' => 'yeti'
];
