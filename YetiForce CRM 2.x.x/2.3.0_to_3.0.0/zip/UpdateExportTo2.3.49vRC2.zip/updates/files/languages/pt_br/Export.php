<?php
/* {[The file is published on the basis of YetiForce Public License
 * that can be found in the following directory: licenses/License.html]} */

$languageStrings = [
	'Export' => 'Exportar',
	'LBL_INFO_USER_EXPORT_RECORDS' => "It's only possible to export active users",
	'LBL_EXPORT_TYPE' => 'Type of exported file',
	'LBL_CSV' => 'CSV',
	'LBL_XML' => 'XML',
	'LBL_XML_EXPORT_TPL' => 'Template',
];
