<?php
/**
 * ExportToXml Model Class
 * @package YetiForce.Model
 * @license licenses/License.html
 * @author Radosław Skrzypczak <r.skrzypczak@yetiforce.com>
 */
vimport('modules.Import.helpers.FormatValue');
vimport('modules.Import.helpers.XmlUtils');

class Vtiger_ExportToXml_Model extends Vtiger_Export_Model
{

	protected $attrList = ['crmfield', 'crmfieldtype', 'partvalue', 'constvalue', 'refmoule', 'spec', 'refkeyfld', 'delimiter', 'testcondition'];
	protected $product = false;
	protected $tplName = '';
	protected $tmpXmlPath = '';
	protected $index;
	protected $inventoryFields;

	public function exportData(Vtiger_Request $request)
	{
		$db = PearDatabase::getInstance();
		$xmlExportType = trim($request->get('xmlExportType'));
		if ($xmlExportType) {
			$this->tplName = $xmlExportType;
		}
		$query = $this->getExportQuery($request);
		$query.= ' GROUP BY ' . $this->focus->table_name . '.' . $this->focus->table_index;
		$result = $db->query($query);

		$fileName = str_replace(' ', '_', decode_html(vtranslate($this->moduleName, $this->moduleName)));

		$entries = $db->getArray($result);
		$entriesInventory = [];
		if ($this->moduleInstance->isInventory()) {
			foreach ($entries as $key => $recordData) {
				$entriesInventory[$key] = $this->getEntriesInventory($recordData);
			}
		}
		foreach ($entries as $key => $data) {
			$this->tmpXmlPath = 'cache/import/' . uniqid() . '_.xml';
			$this->xmlList[] = $this->tmpXmlPath;
			$this->index = $key;
			$this->dataRaw = $data;
			if ($this->tplName) {
				$this->createXmlFromTemplate($data, $entriesInventory[$key]);
			} else {
				$this->createXml($this->sanitizeValues($data), $entriesInventory[$key]);
			}
		}
		if (1 < count($entries)) {
			$this->outputZipFile($fileName);
		} else {
			$this->outputFile($fileName);
		}
	}

	public function getEntriesInventory($recordData)
	{
		$db = PearDatabase::getInstance();
		$inventoryFieldModel = Vtiger_InventoryField_Model::getInstance($this->moduleName);
		$this->inventoryFields = $inventoryFieldModel->getFields();
		$table = $inventoryFieldModel->getTableName('data');
		$resultInventory = $db->pquery('SELECT * FROM ' . $table . ' WHERE id = ? ORDER BY seq', [$recordData[$this->focus->table_index]]);
		if ($db->getRowCount($resultInventory)) {
			while ($inventoryRow = $db->getRow($resultInventory)) {
				$entries[] = $inventoryRow;
			}
		}
		return $entries;
	}

	function sanitizeInventoryValue($value, $columnName, $formated = false)
	{
		$inventoryFieldModel = Vtiger_InventoryField_Model::getInstance($this->moduleName);
		$inventoryFields = $inventoryFieldModel->getFields();
		$field = $inventoryFields[$columnName];
		if (!empty($field)) {
			if (in_array($field->getName(), ['Name', 'Reference'])) {
				$value = trim($value);
				if (!empty($value)) {
					$recordModule = Vtiger_Functions::getCRMRecordType($value);
					$displayValueArray = Vtiger_Functions::computeCRMRecordLabels($recordModule, $value);
					if (!empty($displayValueArray)) {
						foreach ($displayValueArray as $k => $v) {
							$displayValue = $v;
						}
					}
					if (!empty($recordModule) && !empty($displayValue)) {
						$value = $recordModule . '::::' . $displayValue;
					} else {
						$value = '';
					}
				} else {
					$value = '';
				}
			} elseif ($formated && !in_array($field->getName(), ['DiscountMode', 'TaxMode'])) {
				$value = $field->getDisplayValue($value);
			} else {
				$value;
			}
		} elseif (in_array($columnName, ['taxparam', 'discountparam', 'currencyparam'])) {
			switch ($columnName) {
//				case 'taxparam':
//					$tax = Vtiger_InventoryField_Model::getTaxParam($value, 0, false);
//					$value = key($tax);
//					break;
				case 'currencyparam':
					$field = $inventoryFields['currency'];
					$valueData = $field->getCurrencyParam([], $value);
					$valueNewData = [];
					foreach ($valueData as $currencyId => &$data) {
						$currencyName = Vtiger_Functions::getCurrencyName($currencyId, false);
						$data['value'] = $currencyName;
						$valueNewData[$currencyName] = $data;
					}
					$value = Zend_Json::encode($valueNewData);
					break;
				default:
					break;
			}
		}
		return html_entity_decode($value);
	}

//	function sanitizeOldInventoryValue($value, $columnName, $formated = false)
//	{
//
//		$inventoryFieldModel = Vtiger_InventoryField_Model::getInstance($this->moduleName);
//		$inventoryFields = $inventoryFieldModel->getFields();
//		$field = $inventoryFields[$columnName];
//		if (!empty($field)) {
//			if (in_array($field->getName(), ['Name', 'Reference'])) {
//				$value = trim($value);
//				if (!empty($value)) {
//					$recordModule = Vtiger_Functions::getCRMRecordType($value);
//					$displayValueArray = Vtiger_Functions::computeCRMRecordLabels($recordModule, $value);
//					if (!empty($displayValueArray)) {
//						foreach ($displayValueArray as $k => $v) {
//							$displayValue = $v;
//						}
//					}
//					if (!empty($recordModule) && !empty($displayValue)) {
//						$value = $recordModule . '::::' . $displayValue;
//					} else {
//						$value = '';
//					}
//				} else {
//					$value = '';
//				}
//			} elseif ($formated && !in_array($field->getName(), ['DiscountMode', 'TaxMode'])) {
//				$value = $field->getDisplayValue($value);
//			} else {
//				$value;
//			}
//		} elseif (in_array($columnName, ['taxparam', 'discountparam', 'currencyparam'])) {
//			switch ($columnName) {
////				case 'taxparam':
////					$tax = Vtiger_InventoryField_Model::getTaxParam($value, 0, false);
////					$value = key($tax);
////					break;
//				case 'currencyparam':
//					$field = $inventoryFields['currency'];
//					$valueData = $field->getCurrencyParam([], $value);
//					$valueNewData = [];
//					foreach ($valueData as $currencyId => &$data) {
//						$currencyName = Vtiger_Functions::getCurrencyName($currencyId, false);
//						$data['value'] = $currencyName;
//						$valueNewData[$currencyName] = $data;
//					}
//					$value = Zend_Json::encode($valueNewData);
//					break;
//				default:
//					break;
//			}
//		}
//		return html_entity_decode($value);
//	}

	public function outputFile($fileName)
	{
		header("Content-Disposition:attachment;filename=$fileName.xml");
		header("Content-Type:text/csv;charset=UTF-8");
		header("Expires: Mon, 31 Dec 2000 00:00:00 GMT");
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
		header("Cache-Control: post-check=0, pre-check=0", false);

		readfile($this->tmpXmlPath);
	}

	protected function outputZipFile($fileName)
	{

		$zipName = 'cache/import/' . uniqid() . '.zip';

		$zip = new ZipArchive();
		$zip->open($zipName, ZipArchive::CREATE);

		for ($i = 0; $i < count($this->xmlList); $i++) {
			$xmlFile = basename($this->xmlList[$i]);
			$xmlFile = explode('_', $xmlFile);
			array_shift($xmlFile);
			$xmlFile = $fileName . $i . implode('_', $xmlFile);
			$zip->addFile($this->xmlList[$i], $xmlFile);
		}

		$zip->close();

		header("Content-Disposition:attachment;filename=$fileName.zip");
		header("Content-Type:application/zip");
		header("Expires: Mon, 31 Dec 2000 00:00:00 GMT");
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
		header("Cache-Control: post-check=0, pre-check=0", false);

		readfile($zipName);
	}

	public function createXml($entries, $entriesInventory)
	{
		$xml = new XMLWriter();
		$xml->openMemory();
		$xml->setIndent(TRUE);
		$xml->startDocument('1.0', 'UTF-8');

		$xml->startElement('MODULE_FIELDS');
		$xml = $this->setXMLStandardFieldsData($xml, $entries);
		if ($entriesInventory) {
			$customColumns = [];
			$xml->startElement('INVENTORY_ITEMS');
			foreach ($entriesInventory as $inventory) {
				unset($inventory['id']);
				$xml->startElement('INVENTORY_ITEM');
				while (list($columnName, $value) = each($inventory)) {
					$xml->startElement($columnName);
					$fieldModel = $this->inventoryFields[$columnName];
					if ($fieldModel) {
						$xml->writeAttribute('label', vtranslate(html_entity_decode($fieldModel->get('label'), ENT_QUOTES), $this->moduleName));
						if (!in_array($columnName, $customColumns)) {
							foreach ($fieldModel->getCustomColumn() as $key => $dataType) {
								$customColumns[$key] = $columnName;
							}
						}
					}
					if ($this->isCData($columnName, $customColumns)) {
						$xml->writeCData($this->sanitizeInventoryValue($value, $columnName, true));
					} else {
						$xml->text($this->sanitizeInventoryValue($value, $columnName, true));
					}
					$xml->endElement();
				}
				$xml->endElement();
			}
			$xml->endElement();
		}
		$xml->endElement();
		file_put_contents($this->tmpXmlPath, $xml->flush(true), FILE_APPEND);
	}

	public function setXMLStandardFieldsData(XMLWriter $xml, $entries)
	{
		foreach ($this->moduleFieldInstances as $fieldName => $fieldModel) {
			if (!in_array($fieldModel->get('presence'), [0, 2])) {
				continue;
			}
			$xml->startElement($fieldName);
			$xml->writeAttribute('label', vtranslate(html_entity_decode($fieldModel->get('label'), ENT_QUOTES), $this->moduleName));
			if ($this->isCData($fieldName)) {
				$xml->writeCData($entries[$fieldName]);
			} else {
				$xml->text($entries[$fieldModel->get('column')]);
			}
			$xml->endElement();
		}
		return $xml;
	}

	public function isCData($name, $customColumns = [])
	{
		if ($customColumns) {
			return array_key_exists($name, $customColumns);
		}
		$fieldModel = $this->moduleFieldInstances[$name];
		if ($fieldModel && $fieldModel->getFieldDataType() == 'text') {
			return true;
		}
		return false;
	}
	/*
	 * TODO
	 */

	public function createXmlFromTemplate($entries, $entriesInventory)
	{
		$xml = new XMLWriter();
		$xml->openMemory();
		$xml->setIndent(TRUE);
		$xml->startDocument('1.0', 'UTF-8');

		$tpl = Import_Utils_Helper::readTpl($this->tplName);

		$raw = $entries;
		$entries = $this->sanitizeValues($entries);
		while ($tpl->read()) {
			if (XMLReader::ELEMENT == $tpl->nodeType) {
				if ('true' != $tpl->getAttribute('notrepeat')) {
					$xml->startElement($tpl->name);
				}
				if (($tpl->getAttribute('crmfield') || $tpl->getAttribute('constvalue')) && ('product' != $tpl->getAttribute('type') && 'true' != $tpl->getAttribute('notrepeat'))) {
					$xml->text($this->getNodeValue($tpl, $entries, $entriesInventory));
				}
				if ('allmodulefields' == $tpl->getAttribute('type')) {
					$xml = $this->setXMLStandardFieldsData($xml, $entries);
				} elseif (in_array($tpl->getAttribute('type'), ['product']) && ($entriesInventory || in_array($this->moduleName, getInventoryModules()))) {
					$lineProductTpl = new SimpleXMLElement($tpl->readInnerXml());
					$ID = $raw[$this->focus->table_index];
					$focus = new $this->moduleName();
					$focus->retrieve_entity_info($ID, $this->moduleName);
					$focus->id = $ID;
					$products = getAssociatedProducts($this->moduleName, $focus, $ID);
					$this->finalDetails = $products ? $products[1]['final_details'] : [];
					$xml = $this->addInventoryItems($xml, $products, $lineProductTpl, $entries);
					$this->finalDetails = [];
				}
			} else if (XMLReader::END_ELEMENT == $tpl->nodeType) {
				if ('true' != $tpl->getAttribute('notrepeat')) {
					$xml->endElement();
				}
			}
		}
		file_put_contents($this->tmpXmlPath, $xml->flush(true), FILE_APPEND);
	}

	protected function addInventoryItems(XMLWriter $xml, $entriesInventory, SimpleXMLElement $lineProductTpl, $entriesData)
	{
		if (empty($this->inventoryFields)) {
			$this->inventoryFields = [];
			$allFields = Vtiger_InventoryField_Model::getAllFields();
			foreach ($allFields as $field) {
				$this->inventoryFields[$field->getColumnName()] = $field;
			}
		}
		foreach ($entriesInventory as $key => $inventory) {
			if (!empty($inventory['productDeleted' . $key])) {
				continue;
			}
			$xml->startElement('INVENTORY_ITEM');
			foreach ($lineProductTpl as $singele) {
				$nodeName = $singele->getName();
				$xml->startElement($nodeName);
				$value = $this->getValueFromName($inventory, $nodeName, $key, $entriesData);
				$fieldModel = $this->inventoryFields[$nodeName];
				if ($fieldModel) {
					$defaultLabel = $fieldModel->getDefaultLabel();
					$xml->writeAttribute('label', vtranslate(html_entity_decode($defaultLabel, ENT_QUOTES), $this->moduleName));
				} elseif (!in_array($nodeName, ['discountparam', 'taxparam', 'currencyparam', 'qtyparam'])) {
					$defaultLabel = $this->getDefaultInventoryLabel($nodeName);
					$xml->writeAttribute('label', vtranslate(html_entity_decode($defaultLabel, ENT_QUOTES), $this->moduleName));
				}
				if (in_array($nodeName, ['discountparam', 'taxparam', 'currencyparam', 'qtyparam', 'comment1', 'name'])) {
					$xml->writeCData($value);
				} else {
					$xml->text($value);
				}
				$xml->endElement();
			}
			$xml->endElement();
		}
		return $xml;
	}

	public function getDefaultInventoryLabel($name)
	{
		$data = [
			'seq' => 'Lp.',
			'unit' => 'Unit',
			'subunit' => 'Subunit',
			'qty' => 'Quantity',
			'price' => 'Unit price',
			'total' => 'Net',
			'discount' => 'Discount',
			'net' => 'Price after discount',
			'tax' => 'Tax',
			'gross' => 'Gross',
			'comment1' => 'Comment',
			'name' => 'Item Name'
		];
		return $data[$name];
	}

	public function getValueFromName($data, $name, $index, $entriesData)
	{
		$value = '';
		switch ($name) {
			case 'seq':
				$value = $index;
				break;
			case 'name':
				if ($data['entityType' . $index] && $data['productName' . $index])
					$value = $data['entityType' . $index] . '::::' . $data['productName' . $index];
				break;
			case 'qty':
				$value = CurrencyField::convertToUserFormat($data[$name . $index], null, true);
				break;
			case 'discountmode':
				$value = empty($data['discount_type' . $index]) ? 0 : 1;
				break;
			case 'taxmode':
				$value = ($this->finalDetails && $this->finalDetails['taxtype'] == 'individual') ? 1 : 0;
				break;
			case 'price':
				$value = $data['listPrice' . $index];
				$value = CurrencyField::convertToUserFormat($value, null, true);
				break;
			case 'discount':
				$value = $data['discountTotal' . $index];
				$value = CurrencyField::convertToUserFormat($value, null, true);
				break;
			case 'gross':
				$value = $data['netPrice' . $index];
				$value = CurrencyField::convertToUserFormat($value, null, true);
				break;
			case 'net':
				$value = $data['totalAfterDiscount' . $index];
				$value = CurrencyField::convertToUserFormat($value, null, true);
				break;
			case 'tax':
				$value = $data['taxTotal' . $index];
				$value = CurrencyField::convertToUserFormat($value, null, true);
				break;
			case 'total':
				$value = $data['productTotal' . $index];
				$value = CurrencyField::convertToUserFormat($value, null, true);
				break;
			case 'taxparam':
				$taxMode = ($this->finalDetails && $this->finalDetails['taxtype'] == 'individual') ? 'individual' : 'global';
				if (($taxMode == 'global') && $this->finalDetails) {
					$tax = $this->finalDetails['tax'];
					$taxes = $this->finalDetails['taxes'];
				} else {
					$tax = $data['tax' . $index];
					$taxes = $data['taxes'];
				}
				if (is_array($taxes)) {
					foreach ($taxes as $taxData) {
						if ($taxData['taxname'] == $tax) {
							$value = $taxData['percentage'];
						}
					}
				}
				$value = '{"aggregationType":"individual","individualTax":"' . $value . '"}';
				break;
			case 'discountparam':
				$discontType = empty($data['discount_type' . $index]) ? 'global' : 'individual';
				if ($discontType == 'individual') {
					$type = $data['discount_type' . $index];
					if ($type == 'percentage') {
						$val = $data['discount_percent' . $index];
					} else {
						$val = $data['discount_amount' . $index];
					}
					$value = '{"aggregationType":"individual","individualDiscount":"' . $val . '","individualDiscountType":"' . $type . '"}';
				} else {
					if ($this->finalDetails) {
						$discont = $this->finalDetails['discount_type_final'];
						if ($discont == 'percentage') {
							$discountPercentage = $this->finalDetails['discount_percentage_final'];
							$value = '{"aggregationType":"global","globalDiscount":"' . $discountPercentage . '"}';
						} elseif ($discont == 'amount') {
							$discountAmount = $this->finalDetails['discount_amount_final'];
							$hdnSubTotal = $this->finalDetails['hdnSubTotal'];
							$da = $discountAmount + $hdnSubTotal;
							$discountPercentage = ($discountAmount * 100) / $da;
							$value = '{"aggregationType":"global","globalDiscount":"' . $discountPercentage . '"}';
						}
					}
				}
				break;
			case 'comment1':
				$value = $data['comment' . $index];
				break;
			case 'currency':
				$value = $entriesData['currency_id'];
				if (!empty($value) && is_numeric($value)) {
					$value = Vtiger_Functions::getCurrencyName($value, false);
				}
				break;
			case 'currencyparam':
				$value = $entriesData['currency_id'];
				if (!empty($value) && is_numeric($value)) {
					$currency = Vtiger_Functions::getAllCurrency();
					if (!empty($currency[$value])) {
						$currencyName = $currency[$value]['currency_name'];
						$conversion = $currency[$value]['conversion_rate'];
						$value = '{"' . $currencyName . '":{"date":"","value":"' . $currencyName . '","conversion":"' . $conversion . '"}}';
					}
				}
				break;
			case 'qtyparam':
				$value = 0;
				break;
			case 'unit':
				if (isRecordExists($data['hdnProductId' . $index])) {
					$prodModel = Vtiger_Record_Model::getInstanceById($data['hdnProductId' . $index], $data['entityType' . $index]);
					if ($prodModel) {
						$usageunit = $prodModel->get('usageunit');
						if (in_array($usageunit, ['Box', 'Carton', 'Dozen', 'Pack', 'Reams'])) {
							$value = 'pack';
						} elseif ($usageunit == 'Lb') {
							$value = 'kg';
						} elseif ('M' == $usageunit) {
							$value = 'm';
						} elseif (in_array($usageunit, ['Pieces', 'Quantity'])) {
							$value = 'pcs';
						}
					}
				}
				break;
			case 'subunit':
				break;
			case 'purchase':
				$value = $data['purchase' . $index];
				$value = CurrencyField::convertToUserFormat($value, null, true);
				break;
			case 'marginp':
				$value = $data['marginp' . $index];
				$value = CurrencyField::convertToUserFormat($value, null, true);
				break;
			case 'margin':
				$value = $data['margin' . $index];
				$value = CurrencyField::convertToUserFormat($value, null, true);
				break;
			default:
				break;
		}
		return $value;
	}

	public function getValueFromType($data, $crmField, $fromType)
	{
		$columns = explode('|', $crmField);
		foreach ($columns as $columnName) {
			if (isset($data[$columnName])) {
				return $data[$columnName];
			}
		}
		return null;
	}
}
