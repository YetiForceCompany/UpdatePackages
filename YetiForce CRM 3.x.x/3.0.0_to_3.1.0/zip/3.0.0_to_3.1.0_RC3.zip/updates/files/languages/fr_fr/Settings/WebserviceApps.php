<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'LBL_APP_NAME' => 'Nom',
	'LBL_ADDRESS_URL' => 'URL',
	'LBL_TYPE_SERVER' => 'Type',
	'LBL_API_KEY' => 'Clé',
	'LBL_ADD_APPLICATION' => 'Ajouter une clé',
	'LBL_WEBSERVICE_APPS' => 'Applications - Web service',
	'LBL_WEBSERVICE_APPS_DESCRIPTION' => 'Merci de noter que ce module sera pleinement opérationnel en v.3.1',
	'LBL_PASS' => 'Mot de passe',
];
$jsLanguageStrings = [
	'JS_DELETE_CONFIRMATION' => 'Etes-vous sûr de vouloir supprimer cette clé?',
];
