<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$CONFIG = [
	// Columns visible in Account hierarchy [$label => $columnName]
	'COLUMNS_IN_HIERARCHY' => [],
	// Max depth of hierarchy
	'MAX_HIERARCHY_DEPTH' => 50,
];
