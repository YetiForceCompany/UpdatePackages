<?php
/* * *******************************************************************************
 * * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * Contributor(s): YetiForce.com
 * ********************************************************************************** */

$languageStrings = [
	'Webservices' => 'Webservices',
	'LBL_CHANGE_PASSWORD_FAILURE' => 'Echec du changement de mot de passe',
	'LBL_DATABASE_QUERY_ERROR' => 'Erreur au niveau Db lors de l\'opération',
	'LBL_INVALID_OLD_PASSWORD' => 'Valeur invalide pour ancien mot de passe.',
	'LBL_NEW_PASSWORD_MISMATCH' => 'Ancien et nouveau mot de passe ne concordent pas',
];
