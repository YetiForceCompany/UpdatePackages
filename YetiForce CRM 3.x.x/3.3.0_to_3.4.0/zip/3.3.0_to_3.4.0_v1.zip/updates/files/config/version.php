<?php
return [
	'appVersion' => '3.4.0',
	'patchVersion' => '2016.10.10',
	'lib_mPDF' => '0.0.0',
	'lib_roundcube' => '0.0.2',
	'lib_PHPExcel' => '0.0.0',
	'lib_AJAXChat' => '0.0.0',
];
