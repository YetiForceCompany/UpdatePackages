<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'LBL_ENSEIGNES_INFORMATION' => 'Détails de l\'Enseigne',
	'Enseignes' => 'Enseignes',
	'SINGLE_Enseignes' => 'Enseignes',
	'Enseignes ID' => 'Enseignes ID',
	'LBL_CUSTOM_INFORMATION' => 'Détails description',
	'enseignes' => 'Enseignes',
];
