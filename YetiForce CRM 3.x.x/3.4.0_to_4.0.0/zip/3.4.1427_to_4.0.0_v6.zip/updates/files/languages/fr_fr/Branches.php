<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'Society' => 'Société',
	'LBL_BRANCHES_INFORMATION' => 'Détails de la Succursale',
	'Branches' => 'Succursales',
	'Branches' => 'Succursales',
	'Branches ID' => 'Succursales ID',
	'LBL_CUSTOM_INFORMATION' => 'Informations Complémentaires',
	'society' => 'Société',
];
