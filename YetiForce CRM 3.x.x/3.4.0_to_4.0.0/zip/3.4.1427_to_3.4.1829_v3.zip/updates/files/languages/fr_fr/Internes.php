<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'LBL_INTERNES_INFORMATION' => 'Détails de l\'Utilisateur',
	'Internes' => 'Utilisateurs',
	'SINGLE_Internes' => 'Utilisateur',
	'Internes ID' => 'Utilisateur ID',
	'LBL_CUSTOM_INFORMATION' => 'Détails description',
	'Internes' => 'Utilisateurs',
];
