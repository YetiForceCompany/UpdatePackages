<?php
return [
	'appVersion' => '4.0.0',
	'patchVersion' => '2017.02.14',
	'lib_mPDF' => '0.0.2',
	'lib_roundcube' => '0.0.24',
	'lib_PHPExcel' => '0.0.0',
	'lib_AJAXChat' => '0.0.2',
	'lib_gantt' => '0.0.0',
];
