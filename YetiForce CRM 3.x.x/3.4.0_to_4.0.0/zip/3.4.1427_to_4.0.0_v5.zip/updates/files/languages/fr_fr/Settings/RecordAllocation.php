<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'LBL_SORTING_SETTINGS_WORNING' => 'Attention!<br> La configuration sera fonctionnelle seulement si vous l\'activez via les rôles',
	'LBL_ADD_PANEL_TO_MODULE' => 'Ajouter une allocation au module',
	'LBL_SELECT_MODULE' => 'Sélectionner le module',
	'LBL_GO_TO_PANEL' => 'Aller au panel',
	'LBL_USERS_AND_GROUPS' => 'Users and groups',
];
$jsLanguageStrings = [
	'JS_ARE_YOU_SURE_YOU_WANT_TO_DELETE_PANEL' => 'Etes-vous sûr de vouloir supprimer toutes les allocations de ce module?',
];

