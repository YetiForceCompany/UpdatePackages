<?php
return [
	'appVersion' => '3.4.1427',
	'patchVersion' => '2017.01.11',
	'lib_mPDF' => '0.0.0',
	'lib_roundcube' => '0.0.15',
	'lib_PHPExcel' => '0.0.0',
	'lib_AJAXChat' => '0.0.0',
	'lib_gantt' => '0.0.0',
];
