<?php namespace Exception;

/**
 * Not Allowed Method Exception class
 * @package YetiForce.Exception
 * @license licenses/License.html
 * @author Mariusz Krzaczkowski <m.krzaczkowski@yetiforce.com>
 */
class NotAllowedMethod extends \Exception
{
	
}
