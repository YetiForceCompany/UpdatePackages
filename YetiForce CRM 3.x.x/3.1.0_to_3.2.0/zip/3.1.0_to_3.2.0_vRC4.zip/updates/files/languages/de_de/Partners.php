<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'Partners' => 'Partner',
	'SINGLE_Partners' => 'Partner',
	
	//BLOCKS
	'LBL_PARTNERS_INFORMATION' => 'Informationen',
	'LBL_CUSTOM_INFORMATION' => 'Systeminformationen',
	'LBL_DESCRIPTION_INFORMATION' => 'Beschreibung Details',

	//FIELDS
	'LBL_SUBJECT' => 'Bezeichnung',
	'LBL_NUMBER' => 'Nummer',
	'LBL_CLOSED_TIME' => 'Beendigungszeit',
	'LBL_VAT_ID' => 'MwSt',

];
