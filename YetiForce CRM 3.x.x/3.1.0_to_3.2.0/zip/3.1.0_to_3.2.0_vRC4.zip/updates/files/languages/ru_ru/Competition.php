<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'Competition' => 'Конкурсанты',
	'SINGLE_Competition' => 'Конкурсант',

	//BLOCKS
	'LBL_COMPETITION_INFORMATION' => 'Основная информация',
	'LBL_CUSTOM_INFORMATION' => 'Дополнительная информация',
	'LBL_DESCRIPTION_INFORMATION' => 'Описание',


	//FIELDS
	'LBL_CLOSED_TIME' => 'Время закрытия',
	'LBL_SUBJECT' => 'Тема',
	'LBL_NUMBER' => 'Номер',
	'LBL_VAT_ID' => 'ИНН',
];
