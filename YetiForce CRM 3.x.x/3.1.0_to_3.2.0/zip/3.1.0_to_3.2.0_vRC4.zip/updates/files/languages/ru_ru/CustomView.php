<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'CustomView' => 'Фильтры - Конфигурация',
	'LBL_FEATURED' => 'Добавить в избранное',
	'LBL_COLOR_VIEW' => 'Посмотреть цвет',
];
