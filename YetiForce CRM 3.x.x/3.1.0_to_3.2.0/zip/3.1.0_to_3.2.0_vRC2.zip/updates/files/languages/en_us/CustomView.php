<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'CustomView' => 'Filters - Configuration',
	'LBL_FEATURED' => 'Add to favorites',
	'LBL_COLOR_VIEW' => 'View color',
];
