<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'Announcements|FL_INTERVAL' => 'Co ile dni wyświetlać użytkownikowi powiadomienie, jeśli nie zapoznał się ze zmianami. Jeśli pole pozostanie puste to przypomnienie nie będzie ponownie wyświetlone.',
	'Accounts|Account Name' => 'Pole przeznaczone na nazwę firmy',
];
