<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'Competition' => 'Concurrence',
	'SINGLE_Competition' => 'Concurrent',
	//BLOCKS
	'LBL_COMPETITION_INFORMATION' => 'Information de base',
	'LBL_CUSTOM_INFORMATION' => 'Information système',
	'LBL_DESCRIPTION_INFORMATION' => 'Description détails',
	//FIELDS
	'LBL_SUBJECT' => 'Sujet',
	'LBL_NUMBER' => 'Nombre',
	'LBL_CLOSED_TIME' => 'Heure de fermeture',
	'LBL_VAT_ID' => 'ID TVA',
];
