<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'LBL_TYPE_NOTIFICATIONS' => 'Benachrichtungstypen',
	'LBL_NOTIFICATIONS_CONFIGURATION' => 'Einstellungen zu Benachrichtigungen',
	'LBL_DEFAULT_MENU' => 'Standard',
	'LBL_TITLE_ADDED' => 'Benachrichtigung erzeugen',
	'LBL_NAME' => 'Typname',
	'LBL_WIDTH' => 'Breite',
	'LBL_HEIGHT' => 'Höhe',
	'LBL_MODULE' => 'Modulname',
	'LBL_USERS_WATCHING' => 'Benutzerüberwachung',
	'LBL_MESSAGES_FROM_USERS' => 'Benutzermeldungen',
	'LBL_WATCHDOG' => 'Änderungen nachverfolgen',
];
$jsLanguageStrings = [
	'JS_DELETE_CONFIRMATION' => 'Wollen Sie dieses Element wirklich löschen?',
	'JS_SAVE_CAHNGES' => 'Änderungen gespeichert',
];
