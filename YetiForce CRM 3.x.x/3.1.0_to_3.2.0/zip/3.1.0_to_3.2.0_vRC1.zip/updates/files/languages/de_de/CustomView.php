<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$languageStrings = [
	'CustomView' => 'Filter - Konfiguration',
	'LBL_FEATURED' => 'Zu Favoriten hinzufügen',
	'LBL_COLOR_VIEW' => 'View color',
];
