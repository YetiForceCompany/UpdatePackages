<?php
/* {[The file is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
$SECURITY_KEYS_CONFIG = [
	// key will be protected backup files
	'backupPassword' => 'yeti',
	// Key to encrypt passwords, changing the key results in the loss of all encrypted data.
	'encryptionPass' => 'yeti',
	// encryption method
	'encryptionMethod' => '',
];
