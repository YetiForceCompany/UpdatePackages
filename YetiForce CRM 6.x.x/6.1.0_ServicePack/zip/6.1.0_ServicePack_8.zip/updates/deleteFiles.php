<?php

return [
'vendor/smarty/'
];
