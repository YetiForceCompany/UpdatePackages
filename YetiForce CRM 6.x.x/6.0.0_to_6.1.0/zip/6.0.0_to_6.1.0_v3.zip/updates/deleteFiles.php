<?php

return [
	'modules/MailIntegration/models/Module.php',
	'vendor',
	'public_html/vendor',
	'public_html/libraries'
];
