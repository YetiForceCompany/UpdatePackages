<?php

return [
	'appVersion' => '6.1.0',
	'patchVersion' => '2020.12.01',
	'lib_roundcube' => '0.1.5'
];
