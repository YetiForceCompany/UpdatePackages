import PNotify from './index.svelte';

export const component = (...args) => new PNotify(...args);
