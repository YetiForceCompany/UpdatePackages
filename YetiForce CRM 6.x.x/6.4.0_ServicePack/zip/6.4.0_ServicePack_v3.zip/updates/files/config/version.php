<?php

return [
	'appVersion' => '6.4.0',
	'patchVersion' => '2022.08.25',
	'lib_roundcube' => '0.3.1',
];
