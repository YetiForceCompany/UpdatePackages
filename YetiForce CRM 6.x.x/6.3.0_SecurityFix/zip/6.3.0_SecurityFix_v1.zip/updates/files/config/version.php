<?php

return [
	'appVersion' => '6.3.11',
	'patchVersion' => '2021.12.15',
	'lib_roundcube' => '0.2.3',
];
