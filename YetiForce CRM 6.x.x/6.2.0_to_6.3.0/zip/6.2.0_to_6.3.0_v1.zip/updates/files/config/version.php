<?php

return [
	'appVersion' => '6.3.0',
	'patchVersion' => '2021.12.10',
	'lib_roundcube' => '0.2.3',
];
