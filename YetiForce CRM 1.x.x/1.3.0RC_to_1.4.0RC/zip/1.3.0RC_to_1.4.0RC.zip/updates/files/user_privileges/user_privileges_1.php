<?php


//This is the access privilege file
$is_admin=true;

$user_info=array('user_name'=>'admin','is_admin'=>'on','user_password'=>'$1$ad000000$hzXFXvL3XVlnUE/X.1n9t/','confirm_password'=>'$1$ad000000$nYTnfhTZRmUP.wQT9y1AE.','first_name'=>'','last_name'=>'Administrator','roleid'=>'H2','email1'=>'help@yetiforce.com','status'=>'Active','activity_view'=>'This Month','lead_view'=>'Today','hour_format'=>'24','start_hour'=>'08:00','reports_to_id'=>'','date_format'=>'yyyy-mm-dd','signature'=>'','description'=>'','accesskey'=>'aOFXop10GCJ1uw0P','time_zone'=>'Europe/Sarajevo','currency_id'=>'1','currency_grouping_pattern'=>'123456789','currency_decimal_separator'=>',','currency_grouping_separator'=>' ','currency_symbol_placement'=>'1.0$','imagename'=>'_DSC6431.jpg','internal_mailer'=>'1','theme'=>'twilight','language'=>'pl_pl','reminder_interval'=>'15 Minutes','phone_crm_extension'=>'','no_of_currency_decimals'=>'2','truncate_trailing_zeros'=>'1','dayoftheweek'=>'Monday','callduration'=>'60','othereventduration'=>'60','calendarsharedtype'=>'private','default_record_view'=>'Summary','leftpanelhide'=>'0','rowheight'=>'medium','defaulteventstatus'=>'Planned','defaultactivitytype'=>'Meeting','hidecompletedevents'=>'0','is_owner'=>'1','end_hour'=>'23:00','currency_name'=>'Poland, Zlotych','currency_code'=>'PLN','currency_symbol'=>'zł','conv_rate'=>'1.00000','record_id'=>'','record_module'=>'','id'=>'1');

?>