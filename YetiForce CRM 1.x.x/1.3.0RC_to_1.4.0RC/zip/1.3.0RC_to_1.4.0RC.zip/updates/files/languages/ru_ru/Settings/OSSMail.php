<?php
/* +********************************************************************************
 * Terms & Conditions are placed on the: http://opensaas.pl
 * *******************************************************************************
 *  Module				: OSSMail
 *  Author				: OpenSaaS Sp. z o.o. 
 *  Help/Email			: bok@opensaas.pl
 *  Website				: www.opensaas.pl
   * VERSION YetiForceCRM: 1.1.0 RC
 * *******************************************************************************+ */
$languageStrings = array(
	'OSSMail'	=>	'Почта',
);

$jsLanguageStrings = array(
    'JS_ERROR_EMPTY' => 'Все поля должны быть заполнены',
);