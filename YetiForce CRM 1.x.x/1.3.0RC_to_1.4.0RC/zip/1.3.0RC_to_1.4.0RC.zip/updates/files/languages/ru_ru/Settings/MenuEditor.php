<?php

$languageStrings = array(
	'LBL_SAVE_COLOR' => 'Изменения успешно сохранены',
	'LBL_SELECT_COLOR' => 'Цвет',
	'LBL_EDIT_COLOR' => 'Изменение цвета',
	'LBL_UPDATE_COLOR' => 'Изменить',
	'LBL_ACTIVE' => 'Активен',
	'LBL_TOOLS' => 'Действие',
	'LBL_COLOR' => 'Цвет',
	'LBL_MODULE' => 'Модуль',
	'LBL_MDULES_COLOR_EDITOR_DESCRIPTION' => 'Менеджер цветов модулей',
	'LBL_MDULES_COLOR_EDITOR' => 'Редактор цвета Модулей',
);