<?php

$languageStrings = array(
	'LBL_SUBJECT' => 'Тема',
	'LBL_DESCRIPTION' => 'Описание',
	'LBL_TEMPLATE_NAME' => 'Название шаблона',
);