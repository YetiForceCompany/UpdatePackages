<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
  * VERSION YetiForceCRM: 1.1.0 RC
 *************************************************************************************/
$languageStrings = array(
	'OSSDocumentControl' => 'Менеджер документов',
	'Document Control'	=>	'Менеджер документов',
	'LBL_ENTER_BASIC_INFO'	=>	'Введите основную информацию',
	'LBL_STEP_1'	=>	'Шаг 1',
	'NEXT'	=>	'Далее',
	'CANCEL'	=>	'Отмена',
);

$jsLanguageStrings = array(
	'OSSDocumentControl' => 'Менеджер документов',
	'Document Control'	=>	'Менеджер документов',
	'DES_REQUIRED'	=>	'Введите описание документа',
	'DES_NAME_REQUIRED'	=>	'Введите название документа',
);