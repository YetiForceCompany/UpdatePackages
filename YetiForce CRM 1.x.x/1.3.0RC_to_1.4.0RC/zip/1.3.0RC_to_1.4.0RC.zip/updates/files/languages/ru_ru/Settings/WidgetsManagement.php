<?php
/*+***********************************************************************************************************************************
 * The contents of this file are subject to the YetiForce Public License Version 1.1 (the "License"); you may not use this file except
 * in compliance with the License.
 * Software distributed under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.
 * See the License for the specific language governing rights and limitations under the License.
 * The Original Code is YetiForce.
 * The Initial Developer of the Original Code is YetiForce. Portions created by YetiForce are Copyright (C) www.yetiforce.com. 
 * All Rights Reserved.
 *************************************************************************************************************************************/
$languageStrings = array(
	'LBL_CHOISE_AUTHORIZED'	=>	'Роль',
	'LBL_ADD_DASHBOARD_BLOCK'	=>	'Добавить Блок Виджетов для Роли',
	'LBL_WIDTH'	=>	'Ширина',
	'LBL_HEIGHT'	=>	'Высота',
	'LBL_ADD_WIDGET'	=>	'Виджет',
	'LBL_ADD_NOTEBOOK'	=>	'Блокнот',
	'LBL_ADD_MINILIST'	=>	'Виджет с фильтром',
	'LBL_SELECT_WIDGET'	=>	'Виджет',
	'LBL_CREATE_CUSTOM_FIELD'	=>	'Добавление Виджета',
	'LBL_ADD_CONDITION'	=>	'Добавить Роль',
	'LBL_INVALID_DATA'	=>	'Неверные данные',

	'WidgetsManagement'	=>	'Менеджер Виджетов',
	'LBL_WIDGETS_MANAGEMENT' => 'Менеджер Виджетов',
	'LBL_WIDGETS_MANAGEMENT_DESCRIPTION'	=>	' Менеджер управления Виджетами',
	'LBL_MANDATORY_WIDGET'	=>	'Обязательный Виджет',
	'LBL_WIDGET' => 'Виджеты',
	'LBL_NUMBER_OF_RECORDS_DISPLAYED'	=>	'Отображаемое количество записей',
	'LBL_DEFAULT_FILTER' => 'Фильтр по умолчанию',
	'LBL_FILTERS_AVAILABLE' => 'Доступные фильтры',
	'LBL_PLEASE_SELECT_ATLEAST_ONE_OPTION' => 'Необходимо выбрать, как минимум 1 пункт',
);
$jsLanguageStrings = array(
	'JS_BLOCK_ADDED'	=>	'Блок Виджетов успешно добавлен',
	'JS_CUSTOM_FIELD_ADDED'	=>	'Виджет успешно добавлен',
	'JS_CUSTOM_FIELD_DELETED'	=>	'Виджет успешно добавлен',
	'JS_CUSTOM_BLOCK_DELETED'	=>	'Блок Виджетов успешно удален',
	'JS_FIELD_EMPTY'	=>	'Поле не может быть пустым',
	'JS_FILTERS_AVAILABLE' => 'Доступные фильтры',
);