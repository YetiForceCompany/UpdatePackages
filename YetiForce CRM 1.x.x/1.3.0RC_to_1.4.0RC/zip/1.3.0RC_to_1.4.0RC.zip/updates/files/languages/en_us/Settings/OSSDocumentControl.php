<?php

$languageStrings = array(
	'Document Control' => 'Document Control',
	'OSSDocumentControl' => 'Document Control',
    'LBL_ENTER_BASIC_INFO' => 'Enter the basic information',
    'LBL_STEP_1' => 'Step 1',
    'NEXT' => 'Next',
    'CANCEL' => 'Cancel',
);

$jsLanguageStrings = array(
	'Document Control' => 'Document Control',
	'OSSDocumentControl' => 'Document Control',
    'DES_REQUIRED' => 'Description of the document is required',
    'DES_NAME_REQUIRED' => 'Name of the document is required',
);