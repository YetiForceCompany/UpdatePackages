<?php
$languageStrings = array(
	'Users' => 'Usuários',
    'USER_MAIL_EXIST' => 'Já existe um Usuário com este endereço de e-mail',
);

$jsLanguageStrings = array(
    'JS_USER_MAIL_EXIST' => 'Já existe um Usuário com este endereço de e-mail',
	'JS_DECIMAL_SEPERATOR_AND_GROUPING_SEPERATOR_CANT_BE_SAME' => 'O separador de casas decimais e separador de milhar não podem ser iguais',
);
