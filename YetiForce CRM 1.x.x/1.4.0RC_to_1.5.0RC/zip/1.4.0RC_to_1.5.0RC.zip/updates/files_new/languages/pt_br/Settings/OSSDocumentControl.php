<?php

$languageStrings = array(
	'Document Control' => 'Document Control',
	'OSSDocumentControl' => 'Document Control',
    'LBL_ENTER_BASIC_INFO' => 'Digite a informação básica',
    'LBL_STEP_1' => 'Passo 1',
    'NEXT' => 'Próximo',
    'CANCEL' => 'Cancelar',
);

$jsLanguageStrings = array(
	'Document Control' => 'Document Control',
	'OSSDocumentControl' => 'Document Control',
    'DES_REQUIRED' => 'A descirção do documento é obrigatória',
    'DES_NAME_REQUIRED' => 'O nome do documento é obrigatório',
);
