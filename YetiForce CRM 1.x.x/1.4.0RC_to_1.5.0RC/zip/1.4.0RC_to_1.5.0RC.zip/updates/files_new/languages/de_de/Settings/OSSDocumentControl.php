<?php

$languageStrings = [
	'Document Control' => 'Dokumentenkontrolle',
	'OSSDocumentControl' => 'Dokumentenkontrolle',
    'LBL_ENTER_BASIC_INFO' => 'Geben Sie die grundlegenden Informationen ein',
    'LBL_STEP_1' => 'Schritt 1',
    'NEXT' => 'Weiter',
    'CANCEL' => 'Abbrechen',
];

$jsLanguageStrings = [
	'Document Control' => 'Dokumentenkontrolle',
	'OSSDocumentControl' => 'Dokumentenkontrolle',
    'DES_REQUIRED' => 'Beschreibung des Dokuments ist erforderlich',
    'DES_NAME_REQUIRED' => 'Name des Dokuments ist erforderlich',
];
