<?php
$languageStrings = [
	'AJAXChat'  => 'Chat',
];