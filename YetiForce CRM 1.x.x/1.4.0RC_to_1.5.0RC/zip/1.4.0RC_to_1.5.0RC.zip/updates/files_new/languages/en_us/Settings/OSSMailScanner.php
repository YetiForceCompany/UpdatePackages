<?php
$languageStrings = [
	'OSSMailScanner_manual' => 'Mail Scanner',
	'OSSMailScanner' => 'Mail Scanner',
	'Mail Scanner' => 'Mail Scanner',
    
];

$jsLanguageStrings = [
    'start_cron' => 'Cron started',
    'end_cron_ok' => 'Cron tasks finished successfully',
    'end_cron_error' => 'While cron was running an error has appeared',
    'JS_mail_error' => 'Given email address is incorrect',
    'JS_time_error' => 'Given date format is incorrect',
    'JS_StopCron' => 'Manually stop the cron',
    'stop_user' => 'User that stopped scanning',
    'Manually stopped' => 'Stopped manually',
    'OK' => 'ok',
    'In progress' => 'In progress',
    'whether_remove_an_identity' => 'Remove an identity?',
    'removed_identity' => 'Identity deleted',
];


