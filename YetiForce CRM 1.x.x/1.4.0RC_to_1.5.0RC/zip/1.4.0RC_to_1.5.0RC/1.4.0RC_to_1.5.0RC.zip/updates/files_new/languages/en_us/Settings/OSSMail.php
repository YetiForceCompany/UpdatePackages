<?php
/* +********************************************************************************
 * Terms & Conditions are placed on the: http://opensaas.pl
 * *******************************************************************************
 *  Module				: OSSMail
 *  Author				: OpenSaaS Sp. z o.o. 
 *  Help/Email			: bok@opensaas.pl
 *  Website				: www.opensaas.pl
 * *******************************************************************************+ */
$languageStrings = [
    'OSSMail' => 'My mailbox',
];

$jsLanguageStrings = [
    'JS_ERROR_EMPTY' => 'All fields must be completed',
];