<?php
$languageStrings = array(
	'Proposal'	=>	'Планы',
);