<?php
/* +********************************************************************************
 * Terms & Conditions are placed on the: http://opensaas.pl
 * *******************************************************************************
 *  Module				: OSSProjectTemplates
 *  Author				: OpenSaaS Sp. z o.o. 
 *  Help/Email			: bok@opensaas.pl
 *  Website				: www.opensaas.pl
   * VERSION YetiForceCRM: 1.1.0 RC
 * *******************************************************************************+ */
$languageStrings = array(
    'OSSProjectTemplates' => 'Шаблоны Проектов',
    
);