<?php

$languageStrings = array(
    'OSSProjectTemplates' => 'Szablony projektów',
    
);