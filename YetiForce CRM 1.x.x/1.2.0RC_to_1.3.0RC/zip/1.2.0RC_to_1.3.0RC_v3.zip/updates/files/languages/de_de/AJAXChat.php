<?php
$languageStrings = array(
	'AJAXChat'  => 'Chat',
);
