<?php
/*+***********************************************************************************************************************************
 * The contents of this file are subject to the YetiForce Public License Version 1.1 (the "License"); you may not use this file except
 * in compliance with the License.
 * Software distributed under the License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or implied.
 * See the License for the specific language governing rights and limitations under the License.
 * The Original Code is YetiForce.
 * The Initial Developer of the Original Code is YetiForce. Portions created by YetiForce are Copyright (C) www.yetiforce.com. 
 * All Rights Reserved.
 *************************************************************************************************************************************/
$languageStrings = array(
	'TreesManager' => 'Tree Manager',
	'LBL_TREES_MANAGER' => 'Tree Manager',
	'LBL_TREES_MANAGER_DESCRIPTION' => 'Tree Template Manager',
	'LBL_NO_RECORDS_FOUND' => 'No tree templates',
	'LBL_EDIT_TEMPLATE_TREES' => 'Edit tree template',
	'LBL_CREATING_TEMPLATE_TREES' => 'Create tree template',
	'LBL_NAME' => 'Template name',
	'LBL_MODULE' => 'Module',
	'LBL_ADD_ITEM_TREE' => 'Add new item',
	'LBL_ADD_TO_TREES' => 'Add',
	'LBL_SAVE' => 'Save',
);
$jsLanguageStrings = array(
	'JS_TREE_DELETED_SUCCESSFULLY' => 'Tree template deleted successfully',
	'JS_JSTREE_CREATE' => 'Add',
	'JS_JSTREE_RENAME' => 'Change name',
	'JS_JSTREE_REMOVE' => 'Delete',
	'JS_JSTREE_CCP' => 'Edit',
	'JS_JSTREE_CUT' => 'Cut',
	'JS_JSTREE_COPY' => 'Copy',
	'JS_JSTREE_PASTE' => 'Paste',
);