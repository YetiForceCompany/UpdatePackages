<?php
 
$languageStrings = array(
    'OSSProjectTemplates' => 'Projekt Vorlagen',
    
);