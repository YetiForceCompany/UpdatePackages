<?php
$languageStrings = array(
    'USER_MAIL_EXIST' => 'User with the e-mail address exists',
);

$jsLanguageStrings = array(
    'JS_USER_MAIL_EXIST' => 'User with the e-mail address exists',
	'JS_DECIMAL_SEPERATOR_AND_GROUPING_SEPERATOR_CANT_BE_SAME' => 'Decimal seperator and Grouping seperator cant be same',
);


