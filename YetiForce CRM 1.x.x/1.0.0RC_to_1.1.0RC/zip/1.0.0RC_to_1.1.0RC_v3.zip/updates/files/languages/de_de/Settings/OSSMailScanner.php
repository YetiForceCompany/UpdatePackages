<?php
$languageStrings = array(
    
);

$jsLanguageStrings = array(
    'start_cron' => 'E-Mail-Scanner gestartet',
    'end_cron_ok' => 'E-Mail-Scanner Aufgabe erfolgreich beendet',
    'end_cron_error' => 'Während der E-Mail-Scanner lief, kam es zu einem Fehler',
    'JS_mail_error' => 'Die E-Mail-Adresse ist fehlerhaft',
    'JS_time_error' => 'Das Datumsformat ist fehlerhaft',
    'JS_StopCron' => 'E-Mail-Scanner manuell stoppen',
    'stop_user' => 'Benutzer hat das E-Mail-Scannen gestoppt',
    'Manually stopped' => 'E-Mail-Scanner manuell gestoppt',
    'OK' => 'Ok',
    'In progress' => 'In Arbeit',
    'whether_remove_an_identity' => 'Eine Identität entfernen',
    'removed_identity' => 'Identität entfernt',
);


