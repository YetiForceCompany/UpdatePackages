<?php
/* +********************************************************************************
 * Terms & Conditions are placed on the: http://opensaas.pl
 * *******************************************************************************
 *  Module				: OSSMail
 *  Author				: OpenSaaS Sp. z o.o. 
 *  Help/Email			: bok@opensaas.pl
 *  Website				: www.opensaas.pl
 *  Brazilian Portuguese Translation - Valmir Carlos Trindade [valmir@ttcasolucoes.com.br] - 08-12-2014 *
 * *******************************************************************************+ */
$languageStrings = array(
    'OSSMail' => 'Minha Caixa de Correio',
);

$jsLanguageStrings = array(
    'JS_ERROR_EMPTY' => 'Todos os campos devem ser preenchidos',
);