<?php

$languageStrings = array(
	'CustomView'	=> 'Benutzerdefinierte Ansichten',
	'LBL_MODULE_DESC'	=> 'Dieses Tool ermöglicht die Erstellung benutzerdefinierter Ansichten für Module. Diese Module müssen Datensätze enthalten und verwenden Standard-Filter im CRM.',
	'Module'	=> 'Modul',
	'ViewName'	=> 'Ansichtsname',
	'SetDefault'	=> 'Standard',
	'Privileges'	=> 'Berechtigungen',
	'Delete'	=> 'Löschen',
	'Delete CustomView'	=> 'Benutzerdefinierte Ansicht wurde gelöscht',
	'Actions'	=> 'Aktionen',
	'Edit'	=> 'Bearbeiten',
);
$jsLanguageStrings = array(
	'Saving changes'	=> 'Speichern von Änderungen...',
	'Update labels'	=> 'Update',
);