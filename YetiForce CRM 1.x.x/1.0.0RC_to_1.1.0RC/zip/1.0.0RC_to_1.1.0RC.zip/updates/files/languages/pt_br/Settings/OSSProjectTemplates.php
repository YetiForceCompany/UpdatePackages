<?php
/*+********************************************************************************
 *  Brazilian Portuguese Translation - Valmir Carlos Trindade [valmir@ttcasolucoes.com.br] - 08-12-2014
 ********************************************************************************+*/
$languageStrings = array(
    'OSSProjectTemplates' => 'Modelos OSSProject',
    
);