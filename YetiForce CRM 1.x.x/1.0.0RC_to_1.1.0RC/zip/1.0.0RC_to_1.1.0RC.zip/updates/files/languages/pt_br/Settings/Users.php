<?php
$languageStrings = array(
    'USER_MAIL_EXIST' => 'Já existe um Usuário com este endereço de e-mail',
);

$jsLanguageStrings = array(
    'JS_USER_MAIL_EXIST' => 'Já existe um Usuário com este endereço de e-mail',
);


