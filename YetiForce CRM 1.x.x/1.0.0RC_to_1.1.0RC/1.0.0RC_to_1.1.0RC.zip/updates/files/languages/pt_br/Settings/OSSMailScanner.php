<?php
 /*+********************************************************************************
 *  Brazilian Portuguese Translation - Valmir Carlos Trindade [valmir@ttcasolucoes.com.br] - 08-12-2014
 ********************************************************************************+*/
$languageStrings = array(
    
);

$jsLanguageStrings = array(
    'start_cron' => 'Cron iniciado',
    'end_cron_ok' => 'As tarefas do Cron foram finalizadas com sucesso',
    'end_cron_error' => 'Ocorreu um erro enquanto o Cron estava sendo executado',
    'JS_mail_error' => 'O email informado está incorreto',
    'JS_time_error' => 'O formato da data informado está incorreto',
    'JS_StopCron' => 'Parar o Cron manualmente',
    'stop_user' => 'Usuário que parou o escanemento',
    'Manually stopped' => 'Parar manualmente',
    'OK' => 'ok',
    'In progress' => 'Realização W',
    'whether_remove_an_identity' => 'Quer remover uma identidade',
    'removed_identity' => 'Identidade apagada',
);


