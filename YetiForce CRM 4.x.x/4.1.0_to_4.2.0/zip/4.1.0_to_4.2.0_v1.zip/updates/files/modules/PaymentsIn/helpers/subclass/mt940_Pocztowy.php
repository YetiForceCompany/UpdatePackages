<?php
/**
 * mt940 pocztowy class
 * @package YetiForce.Helper
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 2.0 (licenses/License.html or yetiforce.com)
 */
Vtiger_Loader::includeOnce('~~modules/PaymentsIn/helpers/mt940.php');

class mt940_Pocztowy extends mt940
{
	
}

?>
