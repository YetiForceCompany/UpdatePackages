<?php
/**
 * Export spanish translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 2.0 (licenses/License.html or yetiforce.com)
 */
$languageStrings = [
	'Export' => 'Exportar',
	'LBL_INFO_USER_EXPORT_RECORDS' => 'Solo se pueden exportar usuarios activos',
];
