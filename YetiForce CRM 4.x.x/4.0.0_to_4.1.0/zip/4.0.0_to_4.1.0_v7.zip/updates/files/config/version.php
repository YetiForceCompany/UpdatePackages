<?php
return [
	'appVersion' => '4.1.0',
	'patchVersion' => '2017.07.31',
	'lib_mPDF' => '0.0.2',
	'lib_roundcube' => '0.0.31',
	'lib_PHPExcel' => '0.0.0',
	'lib_gantt' => '0.0.1',
];
