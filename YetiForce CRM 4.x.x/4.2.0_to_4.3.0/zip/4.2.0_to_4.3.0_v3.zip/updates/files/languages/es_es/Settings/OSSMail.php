<?php
/**
 * OSSMail spanish translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 */
$languageStrings = [
	'OSSMail' => 'Mi buzón',
	'ERR_NO_MODULE_IS_INACTIVE' => 'El módulo "Mi buzón" está inactivo, debe estar habilitado antes de la configuración.'
];

$jsLanguageStrings = [
	'JS_ERROR_EMPTY' => 'Todos los campos deben ser completados',
];
