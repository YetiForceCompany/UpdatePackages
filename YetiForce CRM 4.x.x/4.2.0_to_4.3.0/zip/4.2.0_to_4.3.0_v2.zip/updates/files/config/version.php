<?php
return [
	'appVersion' => '4.3.0',
	'patchVersion' => '2017.12.29',
	'lib_mPDF' => '0.0.2',
	'lib_roundcube' => '0.0.38',
	'lib_PHPExcel' => '0.0.0',
	'lib_gantt' => '0.0.1',
];
