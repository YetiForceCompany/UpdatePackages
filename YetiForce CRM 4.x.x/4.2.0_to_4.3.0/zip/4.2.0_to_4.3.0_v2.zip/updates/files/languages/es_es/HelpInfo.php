<?php
/**
 * HelpInfo spanish translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 */
// Action translation
$languageStrings = [
	'Announcements|FL_INTERVAL' => 'Frecuencia de los recordatorios en días, si un usuario no revisó los cambios. Si el campo permanece vacío, el recordatorio no se mostrará de nuevo.',
	'Accounts|Account Name' => 'Este campo está destinado al nombre de la Empresa',
];
