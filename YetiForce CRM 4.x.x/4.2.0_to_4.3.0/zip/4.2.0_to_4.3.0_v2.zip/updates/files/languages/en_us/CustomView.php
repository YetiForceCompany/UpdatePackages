<?php
/**
 * CustomView english translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 */
$languageStrings = [
	'CustomView' => 'Filters - Configuration',
	'LBL_FEATURED' => 'Add to favorites',
	'LBL_COLOR_VIEW' => 'View color',
];
