<?php
/**
 * Oss mail german translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 * @author skavenkf (K.Fink) 
 */
$languageStrings = [
	'OSSMail' => 'Meine E-Mailbox',
	'ERR_NO_MODULE_IS_INACTIVE' => '"Mein E-Mailbox" Modul ist inaktiv, bitte vor der Konfiguration aktivieren.'
];

$jsLanguageStrings = [
	'JS_ERROR_EMPTY' => 'Alle Felder müssen ausgefüllt werden',
];
