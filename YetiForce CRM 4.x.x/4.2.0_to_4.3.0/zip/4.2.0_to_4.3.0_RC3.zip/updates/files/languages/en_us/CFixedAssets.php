<?php
/**
 * CFixedAssets english translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 */
$languageStrings = [
	'CFixedAssets' => 'Fixed assets',
	'SINGLE_CFixedAssets' => 'Fixed assets',
	//BLOCKS
	'LBL_VEHICLE' => 'Vehicle',
	'LBL_BASIC_INFORMATION' => 'Basic information',
	'LBL_DESCRIPTION_BLOCK' => 'Description',
	'LBL_ATTENTION_BLOCK' => 'Notes',
	//FIELDS
	'FL_SUBJECT' => 'Name',
	'FL_TYPE' => 'Type',
	'FL_STATUS' => 'Status',
	'FL_PRODUCENT_DESIGNATION' => 'Manufacturer\’s marking',
	'FL_ADDITIONAL_DESIGNATION' => 'Additional marking',
	'FL_INTERNAL_DESIGNATION' => 'Internal marking',
	'FL_DATE_PRODUCTION' => 'Production data',
	'FL_DATE_ACQUISITION' => 'Purchase date',
	'FL_PURCHASE_PRICE' => 'Purchase price',
	'FL_ACTUAL_PRICE' => 'Actual price',
	'FL_RESERVATION' => 'Reservation available',
	'FL_CATEGORY' => 'Category',
	'FL_FUEL_TYPE' => 'Fuel type',
	'FL_TIMING_CHANGE' => 'Camshaft replacement period',
	'FL_OIL_TYPE' => 'Oil replacement period',
	'FL_AVARAGE_FUEL_CONSUPTION' => 'Avg fuel consumption per 100 km',
	'FL_CURRENT_ODOMETER_READING' => 'Current odometer reading',
	'FL_NUMBER_REPAIR' => 'Number of repairs',
	'FL_DATE_OF_LAST_REPAIR' => 'Last repair date',
	'FL_MAX_FUEL_CONSUPTION' => 'Max fuel consumption',
	'FL_TYPE_OIL' => 'Oil type',
	'FL_CURRENT_ODOMETER_READING_PORTERS' => 'Current odometer reading at reception',
	'FL_PERIOD_CAR_REVIEW' => 'MOT test period',
	'FL_DATE_CAR_REVIEW' => 'MOT test data',
	'FL_NUMBER_FUEL_CARD' => 'Fuel card number',
	'FL_DATE_INSURANCE' => 'Insurance date',
	'FL_COST_INSURANCE_OC' => 'Liability Insurance cost',
	'FL_COST_INSURANCE_AC' => 'Collision Coverage insurance cost',
	'FL_COST_INSURANCE_NW' => 'Personal Injury Protection insurance cost',
	'FL_NUMBER_MOTOHOURS' => 'Moto hours number',
	'FL_EQUIPMENT' => 'Equipment',
	// Picklist
	'PLL_UNAVAILABLE' => 'Unavailable',
	'PLL_AVAILABLE' => 'Available',
	'PLL_DEMAGED' => 'Damaged',
	'PLL_IN_USE' => 'In use',
	'PLL_UNDER_REPAIR' => 'Under repair',
	'PLL_PENDING_FOR_REPROCESSING' => 'Pending for reprocessing',
	'PLL_PENDING_FOR_SALE' => 'Pending for sale',
	'PLL_REPROCESSED' => 'Reprocessed',
	'PLL_SOLD' => 'Sold',
	'PLL_DEVICE' => 'Device',
	'PLL_MACHINE' => 'Machine',
	'PLL_VEHICLE' => 'Vehicle',
	'PLL_PROPERTY' => 'Property',
	'PLL_INVENTORY' => 'Inventory',
	'PLL_DIESEL' => 'Diesel',
];
