<?php
/**
 * FBookkeeping english translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 */
$languageStrings = [
	'FBookkeeping' => 'Bookkeeping',
	'SINGLE_FBookkeeping' => 'Bookkeeping',
	'FBookkeeping ID' => 'Bookkeeping ID',
	'FL_SUBJECT' => 'Subject',
];
