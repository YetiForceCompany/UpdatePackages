<?php
return [
	'appVersion' => '4.2.618',
	'patchVersion' => '2017.12.07',
	'lib_mPDF' => '0.0.2',
	'lib_roundcube' => '0.0.37',
	'lib_PHPExcel' => '0.0.0',
	'lib_gantt' => '0.0.1',
];
