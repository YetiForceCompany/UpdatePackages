<?php
/**
 * HelpInfo german translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 */
// Action translation
$languageStrings = [
	'Announcements|FL_INTERVAL' => 'Frequenz der Erinnerungen in Tagen, falls ein Benutzer die Änderungen nicht anschaut. Ist das Feld leer, wird die Erinnerung nicht noch einmal angezeigt.',
	'Accounts|Account Name' => 'Diese Feld ist für den Firmenname gedacht',
];
