<?php
return [
	'appVersion' => '4.2.580',
	'patchVersion' => '2017.11.30',
	'lib_mPDF' => '0.0.2',
	'lib_roundcube' => '0.0.36',
	'lib_PHPExcel' => '0.0.0',
	'lib_gantt' => '0.0.1',
];
