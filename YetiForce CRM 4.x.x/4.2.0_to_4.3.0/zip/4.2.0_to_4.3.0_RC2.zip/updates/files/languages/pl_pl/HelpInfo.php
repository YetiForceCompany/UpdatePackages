<?php
/**
 * HelpInfo polish translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 */
$languageStrings = [
	'Announcements|FL_INTERVAL' => 'Co ile dni wyświetlać użytkownikowi powiadomienie, jeśli nie zapoznał się ze zmianami. Jeśli pole pozostanie puste to przypomnienie nie będzie ponownie wyświetlone.',
	'Accounts|Account Name' => 'Pole przeznaczone na nazwę firmy',
];
