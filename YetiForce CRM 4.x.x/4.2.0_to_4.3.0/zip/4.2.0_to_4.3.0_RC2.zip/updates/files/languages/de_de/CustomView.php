<?php
/**
 * CustomView german translation
 * @package YetiForce.Language
 * @copyright YetiForce Sp. z o.o.
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 */
$languageStrings = [
	'CustomView' => 'Filter - Konfiguration',
	'LBL_FEATURED' => 'Zu Favoriten hinzufügen',
	'LBL_COLOR_VIEW' => 'Farben anzeigen',
];
