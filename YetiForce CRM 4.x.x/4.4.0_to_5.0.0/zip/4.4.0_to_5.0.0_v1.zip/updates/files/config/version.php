<?php

return [
	'appVersion' => '4.4.44',
	'patchVersion' => '2018.09.21',
	'lib_mPDF' => '0.0.2',
	'lib_roundcube' => '0.0.54'
];
