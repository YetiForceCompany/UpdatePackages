<?php

return [
	'appVersion' => '5.0.0',
	'patchVersion' => '2019.02.12',
	'lib_roundcube' => '0.0.66'
];
