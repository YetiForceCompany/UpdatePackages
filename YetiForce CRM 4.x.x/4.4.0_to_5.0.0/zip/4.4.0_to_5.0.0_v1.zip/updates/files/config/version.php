<?php

return [
	'appVersion' => '4.4.41',
	'patchVersion' => '2018.09.12',
	'lib_mPDF' => '0.0.2',
	'lib_roundcube' => '0.0.54'
];
