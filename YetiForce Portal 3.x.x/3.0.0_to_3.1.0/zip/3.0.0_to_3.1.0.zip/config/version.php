<?php
/* {[The function is published on the basis of YetiForce Public License that can be found in the following directory: licenses/License.html]} */
/* {[Contributor(s): }] */

$version = '3.1.0';
$patch_version = '20160518';
