<?php

return [
	'appVersion' => '6.0.0',
	'patchVersion' => '2020.11.23',
	'lib_roundcube' => '0.1.0'
];
