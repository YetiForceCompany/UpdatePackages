<?php

return [
	'layouts/basic/modules/ModComments/BreadCrumbs.tpl',
	'layouts/basic/modules/OSSPasswords/DetailViewBlockView.tpl',
	'modules/Calendar/uitypes/ReferenceSubProcess.php',
	'modules/Settings/Vtiger/models/Systems.php',
	'layouts/basic/modules/Vtiger/HelpDeskSummaryWidgetContents.tpl',
	'modules/Vtiger/helpers/Kpi.php',
	'modules/Vtiger/dashboards/Kpi.php',
	'layouts/basic/modules/Vtiger/dashboards/KpiContents.tpl',
	'layouts/basic/modules/Vtiger/dashboards/Kpi.tpl'
];
