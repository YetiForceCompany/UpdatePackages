<?php

return [
	'layouts/basic/modules/Users/PasswordModal.tpl',
	'public_html/libraries/tributejs/dist/tribute.min.js',
	'public_html/libraries/tributejs/dist/tribute.min.js.map',
];
