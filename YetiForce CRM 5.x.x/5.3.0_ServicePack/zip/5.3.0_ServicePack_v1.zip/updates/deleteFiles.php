<?php

return [
	'layouts/basic/modules/Users/PasswordModal.tpl',
];
