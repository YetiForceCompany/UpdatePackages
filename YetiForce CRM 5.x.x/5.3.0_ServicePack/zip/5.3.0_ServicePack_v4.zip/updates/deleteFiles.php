<?php

return [
	'app/SystemWarnings/YetiForce/Updater.php',
	'layouts/basic/modules/Users/PasswordModal.tpl',
	'public_html/libraries/tributejs/dist/tribute.min.js',
	'public_html/libraries/tributejs/dist/tribute.min.js.map',
	'public_html/libraries/clockpicker/dist/bootstrap4-clockpicker.min.js',
	'public_html/libraries/clockpicker/dist/bootstrap4-clockpicker.min.js.map',
];
