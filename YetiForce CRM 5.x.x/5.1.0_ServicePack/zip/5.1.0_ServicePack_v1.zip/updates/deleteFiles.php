<?php

return [
	'modules/API/cron/CalDav.php',
	'modules/API/cron/CardDav.php',
];
