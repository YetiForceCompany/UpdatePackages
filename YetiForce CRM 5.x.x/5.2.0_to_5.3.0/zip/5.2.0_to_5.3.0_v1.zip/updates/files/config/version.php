<?php

return [
	'appVersion' => '5.3.0',
	'patchVersion' => '2020.03.13',
	'lib_roundcube' => '0.0.87'
];
