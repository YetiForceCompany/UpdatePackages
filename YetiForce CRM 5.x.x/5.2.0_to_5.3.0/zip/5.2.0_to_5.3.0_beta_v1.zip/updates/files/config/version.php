<?php

return [
	'appVersion' => '5.2.100',
	'patchVersion' => '2020.01.03',
	'lib_roundcube' => '0.0.84'
];
