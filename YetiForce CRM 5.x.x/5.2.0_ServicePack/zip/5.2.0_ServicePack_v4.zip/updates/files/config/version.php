<?php

return [
	'appVersion' => '5.2.15',
	'patchVersion' => '2019.09.19',
	'lib_roundcube' => '0.0.80'
];
