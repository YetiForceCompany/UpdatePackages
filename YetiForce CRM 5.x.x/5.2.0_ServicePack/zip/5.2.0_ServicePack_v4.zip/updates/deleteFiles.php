<?php

return [
	'public_html/layouts/basic/modules/Settings/SLAPolicy',
];
