<?php

return [
	'appVersion' => '5.2.0',
	'patchVersion' => '2019.09.12',
	'lib_roundcube' => '0.0.80'
];
